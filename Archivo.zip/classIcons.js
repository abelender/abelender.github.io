let classIcons = [
    {
        class: 'Druid',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_druid.jpg', 
    },

    {
        class: 'Hunter',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_hunter.jpg', 
    },

    {
        class: 'Mage',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_mage.jpg', 
    },

    {
        class: 'Paladin',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_paladin.jpg', 
    },

    {
        class: 'Priest',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_priest.jpg', 
    },

    {
        class: 'Rogue',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_rogue.jpg', 
    },

    {
        class: 'Shaman',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_shaman.jpg', 
    },

    {
        class: 'Warlock',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_warlock.jpg', 
    },

    {
        class: 'Warrior',
        src: 'https://wow.zamimg.com/images/wow/icons/large/classicon_warrior.jpg', 
    }
];